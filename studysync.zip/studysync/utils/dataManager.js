// utils/dataManager.js
const fs = require('fs').promises;
const path = require('path');
const { EventEmitter } = require('events');

class DataManager {
    constructor() {
        this.accounts = new Map();
        this.dataDir = path.join(__dirname, '..', 'data');
        this.accountsFile = path.join(this.dataDir, 'accounts.json');
        this.additionalDataFile = path.join(this.dataDir, 'platform_data.json');
        this.backupInterval = 5 * 60 * 1000; // 5 minutes
        this.backupTimer = null;
        this.saveTimer = null;
        this.isInitialized = false;
    }

    async init() {
        try {
            // Ensure data directory exists
            try {
                await fs.access(this.dataDir);
            } catch (error) {
                await fs.mkdir(this.dataDir, { recursive: true });
                console.log(`[${new Date().toISOString()}] Created data directory: ${this.dataDir}`);
            }

            // Load existing data
            await this.loadAccounts();
            
            // Start automated backups
            this.startBackupTimer();
            
            this.isInitialized = true;
            console.log(`[${new Date().toISOString()}] DataManager initialized with ${this.accounts.size} accounts`);
        } catch (error) {
            console.error('Failed to initialize DataManager:', error);
            throw error;
        }
    }

    async loadAccounts() {
        try {
            await fs.access(this.accountsFile);
            const data = await fs.readFile(this.accountsFile, 'utf8');
            const accountsData = JSON.parse(data);
            
            // Convert back to Map with proper date objects
            this.accounts.clear();
            for (const [id, account] of Object.entries(accountsData)) {
                this.accounts.set(id, {
                    ...account,
                    createdAt: new Date(account.createdAt),
                    lastLogin: account.lastLogin ? new Date(account.lastLogin) : null
                });
            }
            
            console.log(`[${new Date().toISOString()}] Loaded ${this.accounts.size} accounts from storage`);
        } catch (error) {
            if (error.code === 'ENOENT') {
                console.log(`[${new Date().toISOString()}] No existing accounts file found, starting fresh`);
            } else {
                console.error('Error loading accounts:', error);
                throw error;
            }
        }
    }

    async loadAdditionalData() {
        try {
            await fs.access(this.additionalDataFile);
            const data = await fs.readFile(this.additionalDataFile, 'utf8');
            const additionalData = JSON.parse(data);
            
            // Convert date strings back to Date objects in messages
            if (additionalData.messages) {
                for (const [chatKey, messages] of Object.entries(additionalData.messages)) {
                    if (Array.isArray(messages)) {
                        additionalData.messages[chatKey] = messages.map(msg => ({
                            ...msg,
                            timestamp: new Date(msg.timestamp)
                        }));
                    }
                }
            }

            // Convert date strings back to Date objects in notifications
            if (additionalData.notifications) {
                for (const [userId, notifications] of Object.entries(additionalData.notifications)) {
                    if (Array.isArray(notifications)) {
                        additionalData.notifications[userId] = notifications.map(notif => ({
                            ...notif,
                            timestamp: new Date(notif.timestamp)
                        }));
                    }
                }
            }

            // Convert date strings in reports
            if (additionalData.reports) {
                for (const [reportId, report] of Object.entries(additionalData.reports)) {
                    additionalData.reports[reportId] = {
                        ...report,
                        timestamp: new Date(report.timestamp)
                    };
                }
            }

            // Convert date strings in groups
            if (additionalData.groups) {
                for (const [groupId, group] of Object.entries(additionalData.groups)) {
                    additionalData.groups[groupId] = {
                        ...group,
                        createdAt: new Date(group.createdAt)
                    };
                }
            }

            console.log(`[${new Date().toISOString()}] Loaded additional platform data`);
            return additionalData;
        } catch (error) {
            if (error.code === 'ENOENT') {
                console.log(`[${new Date().toISOString()}] No existing additional data file found, starting fresh`);
                return null;
            } else {
                console.error('Error loading additional data:', error);
                return null;
            }
        }
    }

    async saveAccounts() {
        if (!this.isInitialized) return;
        
        try {
            // Convert Map to Object for JSON storage
            const accountsData = Object.fromEntries(this.accounts);
            
            // Create backup of current file if it exists
            try {
                await fs.access(this.accountsFile);
                const backupFile = this.accountsFile + `.backup.${Date.now()}`;
                await fs.copyFile(this.accountsFile, backupFile);
                
                // Keep only last 5 backups
                await this.cleanupOldBackups('accounts.json.backup.');
            } catch (error) {
                // File doesn't exist yet, no backup needed
            }
            
            // Write new data
            await fs.writeFile(this.accountsFile, JSON.stringify(accountsData, null, 2));
            console.log(`[${new Date().toISOString()}] Saved ${this.accounts.size} accounts to storage`);
        } catch (error) {
            console.error('Error saving accounts:', error);
            throw error;
        }
    }

    async backupData(additionalData) {
        if (!this.isInitialized) return;
        
        try {
            // Create backup of current file if it exists
            try {
                await fs.access(this.additionalDataFile);
                const backupFile = this.additionalDataFile + `.backup.${Date.now()}`;
                await fs.copyFile(this.additionalDataFile, backupFile);
                
                // Keep only last 5 backups
                await this.cleanupOldBackups('platform_data.json.backup.');
            } catch (error) {
                // File doesn't exist yet, no backup needed
            }
            
            // Add metadata to the backup
            const dataWithMetadata = {
                ...additionalData,
                metadata: {
                    version: '1.0',
                    timestamp: new Date(),
                    totalMessages: additionalData.messages ? 
                        Object.values(additionalData.messages).reduce((sum, msgs) => sum + (Array.isArray(msgs) ? msgs.length : 0), 0) : 0,
                    totalUsers: additionalData.friendships ? Object.keys(additionalData.friendships).length : 0,
                    totalGroups: additionalData.groups ? Object.keys(additionalData.groups).length : 0
                }
            };
            
            // Write additional data
            await fs.writeFile(this.additionalDataFile, JSON.stringify(dataWithMetadata, null, 2));
            console.log(`[${new Date().toISOString()}] Saved additional platform data`);
        } catch (error) {
            console.error('Error saving additional data:', error);
            throw error;
        }
    }

    async cleanupOldBackups(prefix) {
        try {
            const files = await fs.readdir(this.dataDir);
            const backupFiles = files
                .filter(file => file.startsWith(prefix))
                .map(file => ({
                    name: file,
                    path: path.join(this.dataDir, file),
                    timestamp: parseInt(file.split('.').pop())
                }))
                .sort((a, b) => b.timestamp - a.timestamp);

            // Keep only the 5 most recent backups
            const filesToDelete = backupFiles.slice(5);
            for (const file of filesToDelete) {
                await fs.unlink(file.path);
                console.log(`[${new Date().toISOString()}] Deleted old backup: ${file.name}`);
            }
        } catch (error) {
            console.error('Error cleaning up backups:', error);
        }
    }

    async setAccount(id, account) {
        this.accounts.set(id, account);
        // Auto-save after modifications (debounced)
        this.debouncedSave();
    }

    getAccount(id) {
        return this.accounts.get(id);
    }

    async deleteAccount(id) {
        const deleted = this.accounts.delete(id);
        if (deleted) {
            this.debouncedSave();
        }
        return deleted;
    }

    getAllAccounts() {
        return Array.from(this.accounts.values());
    }

    getAccountsCount() {
        return this.accounts.size;
    }

    // Debounced save to avoid too frequent writes
    debouncedSave() {
        if (this.saveTimer) {
            clearTimeout(this.saveTimer);
        }
        this.saveTimer = setTimeout(() => {
            this.saveAccounts().catch(error => {
                console.error('Error in debounced save:', error);
            });
        }, 2000); // Save 2 seconds after last modification
    }

    startBackupTimer() {
        if (this.backupTimer) {
            clearInterval(this.backupTimer);
        }
        
        this.backupTimer = setInterval(() => {
            // This will be called by the main server to backup additional data
            console.log(`[${new Date().toISOString()}] Backup timer triggered`);
        }, this.backupInterval);
    }

    stopBackupTimer() {
        if (this.backupTimer) {
            clearInterval(this.backupTimer);
            this.backupTimer = null;
        }
    }

    // Create a full backup with timestamp
    async createFullBackup() {
        try {
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const backupDir = path.join(this.dataDir, 'backups', timestamp);
            
            // Create backup directory
            await fs.mkdir(backupDir, { recursive: true });
            
            // Backup accounts
            const accountsData = Object.fromEntries(this.accounts);
            await fs.writeFile(
                path.join(backupDir, 'accounts.json'), 
                JSON.stringify(accountsData, null, 2)
            );
            
            // Backup additional data if it exists
            try {
                await fs.access(this.additionalDataFile);
                await fs.copyFile(this.additionalDataFile, path.join(backupDir, 'platform_data.json'));
            } catch (error) {
                // Additional data file doesn't exist yet
            }
            
            // Create backup info file
            const backupInfo = {
                timestamp: new Date(),
                accountsCount: this.accounts.size,
                version: '1.0',
                type: 'full_backup'
            };
            await fs.writeFile(
                path.join(backupDir, 'backup_info.json'), 
                JSON.stringify(backupInfo, null, 2)
            );
            
            console.log(`[${new Date().toISOString()}] Created full backup: ${backupDir}`);
            return backupDir;
        } catch (error) {
            console.error('Error creating full backup:', error);
            throw error;
        }
    }

    // Restore from backup
    async restoreFromBackup(backupPath) {
        try {
            // Verify backup directory exists
            await fs.access(backupPath);
            
            // Load backup info
            const backupInfoPath = path.join(backupPath, 'backup_info.json');
            const backupInfo = JSON.parse(await fs.readFile(backupInfoPath, 'utf8'));
            
            console.log(`[${new Date().toISOString()}] Restoring from backup: ${backupInfo.timestamp}`);
            
            // Restore accounts
            const accountsPath = path.join(backupPath, 'accounts.json');
            await fs.copyFile(accountsPath, this.accountsFile);
            
            // Restore additional data if exists
            const platformDataPath = path.join(backupPath, 'platform_data.json');
            try {
                await fs.access(platformDataPath);
                await fs.copyFile(platformDataPath, this.additionalDataFile);
            } catch (error) {
                console.log('No additional data in backup to restore');
            }
            
            // Reload data
            await this.loadAccounts();
            
            console.log(`[${new Date().toISOString()}] Successfully restored from backup`);
            return true;
        } catch (error) {
            console.error('Error restoring from backup:', error);
            throw error;
        }
    }

    // Get statistics about the data
    getStats() {
        const accounts = Array.from(this.accounts.values());
        const now = new Date();
        const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

        return {
            totalAccounts: accounts.length,
            newAccountsToday: accounts.filter(acc => acc.createdAt > oneDayAgo).length,
            newAccountsThisWeek: accounts.filter(acc => acc.createdAt > oneWeekAgo).length,
            activeToday: accounts.filter(acc => acc.lastLogin && acc.lastLogin > oneDayAgo).length,
            activeThisWeek: accounts.filter(acc => acc.lastLogin && acc.lastLogin > oneWeekAgo).length,
            suspendedAccounts: accounts.filter(acc => acc.suspended).length,
            oldestAccount: accounts.reduce((oldest, acc) => 
                !oldest || acc.createdAt < oldest.createdAt ? acc : oldest, null),
            newestAccount: accounts.reduce((newest, acc) => 
                !newest || acc.createdAt > newest.createdAt ? acc : newest, null)
        };
    }

    // Search accounts by username or email
    searchAccounts(query) {
        const searchTerm = query.toLowerCase();
        return Array.from(this.accounts.values()).filter(account => 
            account.username.toLowerCase().includes(searchTerm) ||
            (account.email && account.email.toLowerCase().includes(searchTerm))
        );
    }

    // Data integrity check
    async performIntegrityCheck() {
        try {
            console.log(`[${new Date().toISOString()}] Starting data integrity check...`);
            
            const issues = [];
            
            // Check accounts
            for (const [id, account] of this.accounts.entries()) {
                if (!account.id || account.id !== id) {
                    issues.push(`Account ID mismatch: ${id} vs ${account.id}`);
                }
                if (!account.username || !account.passwordHash) {
                    issues.push(`Account ${id} missing required fields`);
                }
                if (!account.createdAt || !(account.createdAt instanceof Date)) {
                    issues.push(`Account ${id} has invalid createdAt`);
                }
            }
            
            // Check for orphaned files
            try {
                const files = await fs.readdir(this.dataDir);
                const expectedFiles = ['accounts.json', 'platform_data.json'];
                const backupFiles = files.filter(f => f.includes('.backup.'));
                const backupDirs = files.filter(f => f === 'backups');
                
                const unexpectedFiles = files.filter(f => 
                    !expectedFiles.includes(f) && 
                    !backupFiles.includes(f) && 
                    !backupDirs.includes(f)
                );
                
                if (unexpectedFiles.length > 0) {
                    issues.push(`Unexpected files found: ${unexpectedFiles.join(', ')}`);
                }
            } catch (error) {
                issues.push(`Error reading data directory: ${error.message}`);
            }
            
            if (issues.length > 0) {
                console.warn(`[${new Date().toISOString()}] Data integrity issues found:`, issues);
                return { success: false, issues };
            } else {
                console.log(`[${new Date().toISOString()}] Data integrity check passed`);
                return { success: true, issues: [] };
            }
        } catch (error) {
            console.error('Error during integrity check:', error);
            return { success: false, error: error.message };
        }
    }

    // Get disk usage information
    async getDiskUsage() {
        try {
            const stats = {
                accounts: 0,
                platformData: 0,
                backups: 0,
                total: 0
            };
            
            try {
                const accountsStat = await fs.stat(this.accountsFile);
                stats.accounts = accountsStat.size;
            } catch (e) { /* file doesn't exist */ }
            
            try {
                const platformDataStat = await fs.stat(this.additionalDataFile);
                stats.platformData = platformDataStat.size;
            } catch (e) { /* file doesn't exist */ }
            
            try {
                const files = await fs.readdir(this.dataDir);
                for (const file of files) {
                    if (file.includes('.backup.')) {
                        const filePath = path.join(this.dataDir, file);
                        const fileStat = await fs.stat(filePath);
                        stats.backups += fileStat.size;
                    }
                }
            } catch (e) { /* error reading directory */ }
            
            stats.total = stats.accounts + stats.platformData + stats.backups;
            
            // Convert to human readable format
            const formatBytes = (bytes) => {
                if (bytes === 0) return '0 Bytes';
                const k = 1024;
                const sizes = ['Bytes', 'KB', 'MB', 'GB'];
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
            };
            
            return {
                raw: stats,
                formatted: {
                    accounts: formatBytes(stats.accounts),
                    platformData: formatBytes(stats.platformData),
                    backups: formatBytes(stats.backups),
                    total: formatBytes(stats.total)
                }
            };
        } catch (error) {
            console.error('Error getting disk usage:', error);
            return null;
        }
    }

    // Maintenance operations
    async performMaintenance() {
        console.log(`[${new Date().toISOString()}] Starting maintenance operations...`);
        
        try {
            // Clean up old backups (keep only 10 most recent)
            await this.cleanupOldBackups('accounts.json.backup.');
            await this.cleanupOldBackups('platform_data.json.backup.');
            
            // Perform integrity check
            await this.performIntegrityCheck();
            
            // Create a maintenance backup
            await this.createFullBackup();
            
            console.log(`[${new Date().toISOString()}] Maintenance operations completed`);
            return true;
        } catch (error) {
            console.error('Error during maintenance:', error);
            return false;
        }
    }

    // Graceful shutdown
    async shutdown() {
        console.log(`[${new Date().toISOString()}] DataManager shutting down...`);
        
        // Stop backup timer
        this.stopBackupTimer();
        
        // Clear save timer
        if (this.saveTimer) {
            clearTimeout(this.saveTimer);
        }
        
        // Final save
        if (this.isInitialized) {
            await this.saveAccounts();
            
            // Create final backup
            try {
                await this.createFullBackup();
            } catch (error) {
                console.error('Error creating final backup:', error);
            }
        }
        
        this.isInitialized = false;
        console.log(`[${new Date().toISOString()}] DataManager shutdown complete`);
    }
}

// Export singleton instance
const dataManager = new DataManager();

// Handle process termination
process.on('SIGINT', async () => {
    await dataManager.shutdown();
});

process.on('SIGTERM', async () => {
    await dataManager.shutdown();
});

// Handle uncaught exceptions to ensure data is saved
process.on('uncaughtException', async (error) => {
    console.error('Uncaught Exception:', error);
    try {
        await dataManager.shutdown();
    } catch (shutdownError) {
        console.error('Error during emergency shutdown:', shutdownError);
    }
    process.exit(1);
});

module.exports = dataManager;